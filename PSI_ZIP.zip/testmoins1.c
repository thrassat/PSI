int main () { 

int c = 256 ;


int k = 56 * 8 + c ;  
}
